import pandas as pd
import numpy as np


df1=pd.read_csv('prismaold.csv')
df2=pd.read_csv('prisma.csv')

df2 = df2[(df2['Cloud Type'] == 'AWS') | (df2['Cloud Type'] == 'Azure')]

df_join = df1.merge(right = df2, left_on = df1.columns.to_list(), right_on = df2.columns.to_list(), how = 'outer')


df1.rename(columns= lambda x : x + '_file1', inplace = True)

df2.rename(columns= lambda x : x + '_file2', inplace = True)

df_join = df1.merge(right = df2, left_on = df1.columns.to_list(), right_on = df2.columns.to_list(), how = 'outer')
#print(df_join)
record_present_in_df2 = df_join.loc[df_join[df1.columns.to_list()].isnull().all(axis = 1), df2.columns.to_list()]
#print(record_present_in_df2.empty)

if record_present_in_df2.empty == True:
    print('NO Match')
else:
    print('there is amatch')
    #Remove the prefix which was addedd in previous to merge the two csv files
    record_present_in_df2.columns = [i.replace('_file2',"") for i in record_present_in_df2.columns]
    col = [0]
    record_present_in_df2.drop(record_present_in_df2.columns[col], axis=1)
    record_present_in_df2.reset_index(inplace = True, drop = True)
    for ind in record_present_in_df2.index:
        #print(record_present_in_df2['Severity'][ind])
        record_present_in_df2.at[ind, 'Severity']= input('enter the value:')
        print(record_present_in_df2['Severity'][ind])
        record_present_in_df2.to_csv('prismalatest.csv', index=False)
df1.append(record_present_in_df2)
print(df1)
df1.to_csv('prismalatest.csv')


'''
with open('prismalatest.csv', 'r') as f1:
    original = f1.read()

with open('prismaold.csv', 'a') as f2:
    f2.write(original)
'''
#print(record_present_in_df2)
#df = pd.read_csv('mydata.csv')
#df.drop(df.columns[col], axis=1, inplace=True, index=False)
#print(df)


#df.to_csv('mydata.csv', index=False)
#print(df)
#print(record_present_in_df2)

#record_present_in_df2.to_csv('mydata.csv')





