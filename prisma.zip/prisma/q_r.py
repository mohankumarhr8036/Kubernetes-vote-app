'''
This Script is to generate the custom report template by giving
input of csv files.
'''
import os
import glob
import csv
import pandas as pd
import openpyxl
import numpy as np
#from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.styles import Alignment, PatternFill, Font, Border, Side
from openpyxl.utils import get_column_letter
#from openpyxl.cell import cell
#from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.drawing.image import Image
from openpyxl.chart.marker import DataPoint
from openpyxl.chart import (
    Reference,
    Series,
    BarChart3D,
)
# from openpyxl.chart.shapes import GraphicalProperties
# base path where folder lives
basePath = os.path.dirname(os.path.realpath('__file__'))
csvPath = basePath+'\\'+'csvdata\\'
csvdatafile = []
#store csv files into csvdatafile list
for file in glob.glob(csvPath+"*.csv"):
    csvdatafile.append(file)
#iterate over csvdatafile and call generate_template_xlsx function by inputing the csv files
def get_csv_data():
    """iterate over files and generate template."""
    for file_csv in csvdatafile:
        generate_template_xlsx(file_csv)
# report template generation
def generate_template_xlsx(csvdata):
    """reading csv file and generating template."""
    line1 = []
    li_row = []
    webapplication_name = []
    qidsline = []
    #Read csv file line by line and get qids and webapplication name
    with open(csvdata, 'r', encoding='utf8') as csv_file1:
        csv_reader1 = csv.reader(csv_file1)
        for line in csv_reader1:
            line1.append(line)
            if line[0] == 'QID':
                pos=line.index('QID')
                qidval=line[pos+1]
                if qidval.isdigit():
                    qidsline.append(qidval)
            webapplication_name.append(line[0].split('-'))
    date = str(line1[15][1]).split(' ')[0]
    month = str(line1[15][1]).split(' ')[1]
    year = str(line1[15][1]).split(' ')[2]
    # Read csv file and get the RESULTS rows and append it to li.
    with open(csvdata, 'r', encoding='utf8') as csv_file:
        csv_reader = csv.reader(csv_file)
        for line in csv_reader:
            for qid in qidsline:
                if qid in line:
                    li_row.append(line)
    # get the Glossary row
    qidrow = [q for q in li_row if q[0] == 'QID']
    # get the Details/RESULTS row
    lirow = [v for v in li_row if v[0] != 'QID']
    resultrow = []
    # If details length is greater then 37 remove and less than 37 add empty string to row
    for row in lirow:
        if len(row) > 37:
            row.pop()
        elif len(row) < 37:
            row.append('')
    # concatinate GLOSSARY and RESULTS rows into one 2d list and append it to resultrow
    for item in qidrow:
        pos=item.index('QID')
        qidval=item[pos+1]
        for value in lirow:
            if qidval in value:
                temp=(value + item[pos+2:])
                resultrow.append(temp)
    # changes the position value if cvss v3 base is empty then add value from cvss base column,
    #if evidence column is empty fill the value from result column,
    # if any column is empty then fill 'N/A
    for item in resultrow:
        if item[49] == '':
            item[49] = item[44]
        if item[50] == '':
            item[50] = item[45]
        if item[23] == '':
            item[23] = item[30]
        if item == '':
            item = 'N/A'
    item = 0
    for i in qidrow:
        pos=i.index('QID')
        qidval=i[pos+1]
        if i[9] == '':
            i[9] = 0.0
        if i[14] == '':
            i[14] = int(float(i[9]))
        i[14] = float(i[14])
        if  8.0 <= i[14] <= 10.0:
            i.append('Critical')
        if  6.0 <= i[14] <= 7.9:
            i.append('High')
        if  4.0 <= i[14] <= 5.9:
            i.append('Medium')
        if  2.0 <= i[14] <= 3.9:
            i.append('Low')
        if  0.0 <= i[14] <= 1.9:
            i.append('Info')
        #
        for j in lirow:
            if qidval in j:
                item+=1
        i.append(item)
        item = 0
        i.append('')
    #count the no's of critical, high, medium, low and info vulnerabilities
    critical = 0
    high = 0
    medium = 0
    low = 0
    info = 0
    for i in qidrow:
        pos=i.index('QID')
        qidval=i[pos+17]
        if qidval == 'Critical':
            pos1 = i[pos+18]
            critical+=pos1
        if qidval == 'High':
            pos1 = i[pos+18]
            high+=pos1
        if qidval == 'Medium':
            pos1 = i[pos+18]
            medium+=pos1
        if qidval == 'Low':
            pos1 = i[pos+18]
            low+=pos1
        if qidval == 'Info':
            pos1 = i[pos+18]
            info+=pos1
    total = critical + high + medium + low + info
    #append the row data based on criticality
    qidrowcritical = []
    qidrowhigh = []
    qidrowmedium = []
    qidrowlow = []
    qidrowinfo = []
    qidrow.sort(key = lambda x: x[18], reverse=True)
    for k in qidrow:
        if k[17] == 'Critical':
            qidrowcritical.append(k)
        if k[17] == 'High':
            qidrowhigh.append(k)
        if k[17] == 'Medium':
            qidrowmedium.append(k)
        if k[17] == 'Low':
            qidrowlow.append(k)
        if k[17] == 'Info':
            qidrowinfo.append(k)
    qidrowresult = qidrowcritical + qidrowhigh + qidrowmedium + qidrowlow + qidrowinfo
    #get the qid in order position
    qidsorder = []
    for j in qidrowresult:
        for i in qidsline:
            if i in j:
                qidsorder.append(j[1])
    #Details sheet column names
    licolumn = ['VULNERABILITY', 'ID', 'Detection ID', 'QID', 'Url', 'Param', 'Function',
    'Form Entry Point', 'Access Path', 'Authentication', 'Ajax Request', \
    'Ajax Request ID', 'Ignored', 'Ignore Reason', 'Ignore Date', 'Ignore User',
    'Ignore Comments', 'Detection Date', 'Payload', 'Request Method', 'Request URL',
    'Request Headers', 'Response', 'Evidence', 'Unique ID', 'Flags', 'Protocol',
    'Virtual Host', 'IP', 'Port', 'Result', 'Info', 'CVSS V3 Base1', 'CVSS V3 Temporal1',
    'CVSS V3 Attack Vector1', 'Request Body', 'Potential']
    #Detais sheet column names
    qidcolumn = ['Title', 'Category', 'Severity Level',	'Groups', 'OWASP', 'WASC', 'CWE',
    'CVSS Base','CVSS Temporal', 'Description', 'Impact', 'Solution', 'CVSS V3 Base',
    'CVSS V3 Temporal', 'CVSS V3 Attack Vector']
    #selecting the column from licolumn and qidcolumn
    qidcolumn_summary = ['QID', 'Id',	'Vulnerability', 'Category', 'Severity Level',
    'Groups', 'OWASP', 'WASC', 'CWE',	'CVSS Base', 'CVSS Temporal', 'Description',
    'Impact', 'Solution', 'CVSS V3 Base', 'CVSS V3 Temporal', 'CVSS V3 Attack Vector',
    'Severity', 'Instances', 'References']
    finalcolumn = licolumn + qidcolumn
    df1 = pd.DataFrame(data=qidrowresult, columns=qidcolumn_summary)
    df1_summary = df1[['Vulnerability', 'Instances', 'Severity','Description', 'Impact',
    'Solution', 'References']]
    writer1 = pd.ExcelWriter(f'{webapplication_name[0][0]}.xlsx', engine='openpyxl') # pylint: disable=abstract-class-instantiated
    df1_summary.to_excel(writer1, 'Summary', index=False, startrow=23)
    #workbook1 = writer1.book
    worksheet1 = writer1.sheets['Summary']
    worksheet1 = writer1.sheets['Summary']
    thick_border = Border(left=Side(style='medium'),
    right=Side(style='medium'),
    top=Side(style='medium'),
    bottom=Side(style='medium'))
    #setting thin border
    thin_border = Border(left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin'))
    #setting no border
    no_border = Border(left=Side(style=None),
    right=Side(style=None),
    top=Side(style=None),
     bottom=Side(style=None))
    #setting bottom no border
    bottom_no_border = Border(left=Side(style=None),
    right=Side(style=None),
    top=Side(style=None),
    bottom=Side(style='thin'))
    #setting thin border
    summary_thin_border = Border(left=Side(style='thin', color='2F528F'),
    right=Side(style='thin', color='2F528F'),
    top=Side(style='thin', color='2F528F'),
    bottom=Side(style='thin', color='2F528F'))
    #setting alignment with thin border and row hieght adjustment
    for i in range(25, df1_summary.shape[0]+25):
        worksheet1.row_dimensions[i].height = 78.75
        for row in worksheet1[i]:
            row.border = thin_border
            row.alignment = Alignment(wrap_text=True, vertical='top')
    #setting column width for required cells
    worksheet1.column_dimensions['A'].width = 34.57
    worksheet1.column_dimensions['B'].width = 18.86
    worksheet1.column_dimensions['C'].width = 20.86
    worksheet1.column_dimensions['D'].width = 14.86
    worksheet1.column_dimensions['E'].width = 12.14
    worksheet1.column_dimensions['F'].width = 13.29
    worksheet1.column_dimensions['G'].width = 19.43
    worksheet1.column_dimensions['H'].width = 20.14
    #assigned cell value for A1
    worksheet1['A1'].value = 'Qualys Scanner Report'
    #assigned cell value for A2
    worksheet1['A2'].value = 'Application name: '
    for row in worksheet1['A2:H2']:
        for cell in row:
            cell.border = thick_border
    worksheet1.merge_cells('B2:H2')
    worksheet1['B1'].value = webapplication_name[0][1]
    worksheet1['B2'].value = webapplication_name[0][0]
    worksheet1['B2'].font = Font(bold=True)
    if webapplication_name[0][1] == 'Continuous':
        worksheet1['C1'].value = month + '-' + year
    elif webapplication_name[0][1] == 'OneTime':
        worksheet1['C1'].value = date + '-' + month + '-' + year
    worksheet1['C1'].font = Font(bold=True)
    #assigned cell value for A4
    worksheet1['A4'].value = 'Vulnerabilities of all selected \
scans are consolidated into one report \
so that you can view their evolution.'
    worksheet1.merge_cells('A4:H4')
    #worksheet1['A4'].alignment = Alignment(horizontal='center', vertical='center')
    for row in worksheet1['A4:H4']:
        for cell in row:
            cell.border = thick_border
    #assigned cell value for A6
    worksheet1['A6'].value = 'SISC Infosec'
    worksheet1.row_dimensions[6].height = 61.5
    worksheet1.merge_cells('A6:C6')
    for row in worksheet1['A6:C6']:
        for cell in row:
            cell.border = thick_border
            cell.alignment = Alignment(vertical='top')
    #assigned cell value for D6
    worksheet1['D6'].value = 'Sony India Software Centre\nEmbassy\
Tech Village Bangalore,\nKarnataka 560103 India'
    worksheet1.merge_cells('D6:H6')
    for row in worksheet1['D6:H6']:
        for cell in row:
            cell.border = thick_border
            cell.alignment = Alignment(wrap_text=True, vertical='top')
    #assigned cell value for A8
    worksheet1['A8'].value = 'Vulnerability  Summary'
    worksheet1.row_dimensions[8].height = 15
    worksheet1['A8'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    worksheet1.merge_cells('A8:H8')
    for row in worksheet1['A8:H8']:
        for cell in row:
            cell.border = thin_border
    fill = PatternFill(patternType="solid", start_color="D9E1F2")
    worksheet1['A8'].fill = fill
    #assigned cell value for A9
    worksheet1['A9'].value = 'Severity Classification'
    worksheet1['A9'].font = Font(bold=True)
    worksheet1.row_dimensions[9].height = 36
    worksheet1.merge_cells('A9:B9')
    for row in worksheet1['A9:H9']:
        for cell in row:
            cell.border = thin_border
            cell.alignment = Alignment(vertical='top')
    #assigned cell value for C9
    worksheet1['C9'].value = 'Critical\n[Level -5]'
    worksheet1['C9'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    worksheet1['C9'].font = Font(bold=True)
    fill_c9 = PatternFill(patternType="solid", start_color="FF0000")
    worksheet1['C9'].fill = fill_c9
    #assigned cell value for D9
    worksheet1['D9'].value = 'High\n[Level-4]'
    worksheet1['D9'].font = Font(bold=True)
    worksheet1['D9'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_d9 = PatternFill(patternType="solid", start_color="FFC000")
    worksheet1['D9'].fill = fill_d9
    #assigned cell value for E9
    worksheet1['E9'].value = 'Medium\n[Level-3]'
    worksheet1['E9'].font = Font(bold=True)
    worksheet1['E9'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_e9 = PatternFill(patternType="solid", start_color="FFFF00")
    worksheet1['E9'].fill = fill_e9
    #assigned cell value for F9
    worksheet1['F9'].value = 'Low\n[Level-2]'
    worksheet1['F9'].font = Font(bold=True)
    worksheet1['F9'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_f9 = PatternFill(patternType="solid", start_color="92D050")
    worksheet1['F9'].fill = fill_f9
    #assigned cell value for G9
    worksheet1['G9'].value = 'Info\n[Level-1]'
    worksheet1['G9'].font = Font(bold=True)
    worksheet1['G9'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_g9 = PatternFill(patternType="solid", start_color="76933C")
    worksheet1['G9'].fill = fill_g9
    #assigned cell value for H9
    worksheet1['H9'].value = 'TOTAL'
    worksheet1['H9'].font = Font(bold=True)
    worksheet1['H9'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    worksheet1.row_dimensions[9].height = 36
    for row in worksheet1['C9:H9']:
        for cell in row:
            cell.border = thin_border

    #assigned cell value for C10
    worksheet1['C10'].value = '8.0-10.0'
    worksheet1['C10'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    worksheet1['C10'].font = Font(bold=True)
    fill_c9 = PatternFill(patternType="solid", start_color="FF0000")
    worksheet1['C10'].fill = fill_c9
    #assigned cell value for D9
    worksheet1['D10'].value = '6.0-7.9'
    worksheet1['D10'].font = Font(bold=True)
    worksheet1['D10'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_d9 = PatternFill(patternType="solid", start_color="FFC000")
    worksheet1['D10'].fill = fill_d9
    #assigned cell value for E9
    worksheet1['E10'].value = '4.0-5.9'
    worksheet1['E10'].font = Font(bold=True)
    worksheet1['E10'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_e9 = PatternFill(patternType="solid", start_color="FFFF00")
    worksheet1['E10'].fill = fill_e9
    #assigned cell value for F9
    worksheet1['F10'].value = '2.0-3.9'
    worksheet1['F10'].font = Font(bold=True)
    worksheet1['F10'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_f9 = PatternFill(patternType="solid", start_color="92D050")
    worksheet1['F10'].fill = fill_f9
    #assigned cell value for G9
    worksheet1['G10'].value = '0.0-1.9'
    worksheet1['G10'].font = Font(bold=True)
    worksheet1['G10'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    fill_g9 = PatternFill(patternType="solid", start_color="76933C")
    worksheet1['G10'].fill = fill_g9
    #assigned cell value for H9
    #worksheet1['H10'].value = ''
    worksheet1['H10'].font = Font(bold=True)
    worksheet1['H10'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    worksheet1.row_dimensions[10].height = 22
    for row in worksheet1['C10:H10']:
        for cell in row:
            cell.border = thin_border
    #assigned cell value for A10
    worksheet1['A10'].value = 'Score'
    worksheet1['A10'].font = Font(bold=True)
    #assigned cell value for A11
    worksheet1['A11'].value = 'Count of Vulnerability'
    worksheet1['A11'].font = Font(bold=True)
    worksheet1.row_dimensions[10].height = 15
    worksheet1.merge_cells('A11:B11')
    for row in worksheet1['A11:B11']:
        for cell in row:
            cell.border = thin_border
    #assigned cell value for cells and adjusted alignment
    worksheet1['C11'].value = critical
    worksheet1['C11'].alignment = Alignment(horizontal='center', vertical='center')
    worksheet1['D11'].value = high
    worksheet1['D11'].alignment = Alignment(horizontal='center', vertical='center')
    worksheet1['E11'].value = medium
    worksheet1['E11'].alignment = Alignment(horizontal='center', vertical='center')
    worksheet1['F11'].value = low
    worksheet1['F11'].alignment = Alignment(horizontal='center', vertical='center')
    worksheet1['G11'].value = info
    worksheet1['G11'].alignment = Alignment(horizontal='center', vertical='center')
    worksheet1['H11'].value = total
    worksheet1['H11'].alignment = Alignment(horizontal='center', vertical='center')
    for row in worksheet1['C11:H11']:
        for cell in row:
            cell.border = thin_border
    #assigned cell value for B12
    worksheet1['B13'].value = 'Vulnerability Remediation Timeframe (As per Sony GISS Policy)'
    worksheet1.row_dimensions[12].height = 18.75
    worksheet1['B13'].alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
    worksheet1.merge_cells('B13:F13')
    for row in worksheet1['B13:F13']:
        for cell in row:
            cell.border = thin_border
    worksheet1['B13'].fill = fill
    img = Image(basePath+'\\GISS_Security.png')
    img.anchor = 'B14'
    worksheet1.add_image(img)
    worksheet1['A23'].value = 'Vulnerability and Remediation Details'
    data=worksheet1['A23'].value
    worksheet1.merge_cells('A23:G23')
    worksheet1['A23']=data
    # worksheet1['A17'].alignment = Alignment(horizontal='center', vertical='center')
    for row in worksheet1['A23:G23']:
        for cell in row:
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center', vertical='center')
    worksheet1['A23'].fill = fill
    #filling the colours for cell and value
    for row in range(24, worksheet1.max_row+1):
        for column in "c":
            cell_name = f"{column}{row}"
            if worksheet1[cell_name].value == 'Critical':
                fill_critical = PatternFill(patternType="solid", start_color="FF0000")
                worksheet1[cell_name].fill = fill_critical
            if worksheet1[cell_name].value == 'High':
                fill_high = PatternFill(patternType="solid", start_color="FFC000")
                worksheet1[cell_name].fill = fill_high
            if worksheet1[cell_name].value == 'Medium':
                fill_medium = PatternFill(patternType="solid", start_color="FFFF00")
                worksheet1[cell_name].fill = fill_medium
            if worksheet1[cell_name].value == 'Low':
                fill_low = PatternFill(patternType="solid", start_color="92D050")
                worksheet1[cell_name].fill = fill_low
            if worksheet1[cell_name].value == 'Info':
                fill_info = PatternFill(patternType="solid", start_color="76933C")
                worksheet1[cell_name].fill = fill_info
            worksheet1[cell_name].alignment = Alignment(horizontal='center', vertical='center')
    #setting column B alignment
    for row in range(24, worksheet1.max_row+1):
        for column in "B":
            cell_name = f"{column}{row}"
            worksheet1[cell_name].alignment = Alignment(horizontal='center', vertical='center')
    worksheet1.sheet_view.showGridLines = False
    worksheet1.sheet_view.zoomScale = 80
    writer1.save()
    #dataframe for details page
    df_details = pd.DataFrame(data=resultrow, columns=finalcolumn)
    #df['CVSS V3 Temporal'] = df['CVSS V3 Temporal'].fillna(df['CVSS Base'])
    df_details = df_details[['QID', 'Url', 'Param', 'OWASP', 'CWE', 'CVSS V3 Base',
    'CVSS V3 Temporal', 'CVSS V3 Attack Vector', 'Payload', 'Request Method',
    'Request URL', 'Request Headers', 'Response', 'Evidence'
    ]]
    writer = pd.ExcelWriter(f'{webapplication_name[0][0]}.xlsx', engine='openpyxl', mode='a')# pylint: disable=abstract-class-instantiated
    temp=1
    for uiqid in qidsorder:
        #sheetname = '%s' % uiqid
        df_new = df_details.loc[df_details['QID'] == uiqid]
        df_new.index = np.arange(1, len(df_new) + 1)
        df_new.reset_index(inplace=True)
        df_new.to_excel(writer, sheet_name=str(temp), index=True, startrow=2)
        #workbook = writer.book
        worksheet = writer.sheets[str(temp)]
        worksheet.delete_cols(1)
        worksheet.delete_cols(2)
        worksheet['A3'].value = 'Sl No'
        temp=temp+1
        worksheet.sheet_view.showGridLines = False
        #setting column width for details sheets
        for idx, col in enumerate(worksheet.columns, 1):
            worksheet.column_dimensions[get_column_letter(idx)].width = 10
        #setting row height for all detail sheets
        for i in range(4, df_details.loc[df_details['QID'] == uiqid].shape[0]+4):
            worksheet.row_dimensions[i].height = 121.5
        #setting cell alignment, thin border and fill N/A for empty cell
        for j in worksheet.iter_rows():
            for cell in j:
                cell.alignment = Alignment(wrap_text=True, vertical='top')
                cell.border = thin_border
                if cell.value == '':
                    cell.value = 'N/A'
        #fill the column colour for all the detail sheets
        col_range = worksheet.max_column
        for colu in range(1, col_range + 1):
            cell_header = worksheet.cell(3, colu)
            cell_header.fill = PatternFill(start_color='4F81BD', end_color='4F81BD',
            fill_type='solid')
        #set the row dimension, column dimension
        worksheet.row_dimensions[1].height = 31.5
        worksheet.column_dimensions['B'].width = 21.57
        worksheet.column_dimensions['A'].width = 4.86
        worksheet['B1'].alignment = Alignment(horizontal='center', vertical='center')
        # img = Image('summary_tab.png')
        # img.anchor = 'B1'
        # worksheet.add_image(img)
        for row in worksheet['A1:N1']:
            for cell in row:
                cell.border = no_border
        #setting bottom no border
        for row in worksheet['A2:N2']:
            for cell in row:
                cell.border = bottom_no_border
        #setting hyper link for summary page from details sheet
        worksheet.cell(row=1, column=2).value = '=HYPERLINK("#Summary!A1", "Go To Summary")'
        fill_a2 = PatternFill(patternType="solid", start_color="DAE3F3")
        worksheet['B1'].fill = fill_a2
        worksheet['B1'].border = summary_thin_border
        worksheet['B1'].font = Font(color='2F5597')
        worksheet.sheet_view.zoomScale = 80
    #save the worksheet
    writer.save()
    #reading workbook back to add hyperlink from summary to details page
    wb_book = openpyxl.load_workbook(f'{webapplication_name[0][0]}.xlsx')
    sheet_obj = wb_book.active
    temp=0
    for row1 in range(25, sheet_obj.max_row+1):
        temp=temp+1
        for column in "G":
            cell_name = f"{column}{row1}"
            sheet_obj[cell_name].value = f'=HYPERLINK("#{str(temp)}!A1", "{str(temp)}")'
            sheet_obj[cell_name].alignment = Alignment(horizontal='center', vertical='center')
            sheet_obj[cell_name].font = Font(color='2F5597', underline="single")
    #adding data to create chart
    data = Reference(sheet_obj,  min_row=11, max_row=11, min_col=3, max_col=7)
    #titles = Reference(ws, min_col=8, min_row=9, max_row=9)
    chart = BarChart3D()
    chart.title = webapplication_name[0][0]
    #chart.x_axis.title = 'Vulnerability'
    series = Series(data, title='Vulnerability')
    chart.append(series)
    dates = Reference(sheet_obj, min_col=3, min_row=9, max_row=9, max_col=7)
    chart.set_categories(dates)
    #setting colour for bar chart
    colours = ['FF0000', 'FFC000', 'FFFF00', '92D050', '76933C']
    for i in enumerate(colours):
        pt_point = DataPoint(idx=i[0])
        pt_point.graphicalProperties.solidFill = i[1]
        series.dPt.append(pt_point)
    chart.legend = None
    chart.height =  11# default is 7.5
    chart.width = 12.5 # default is 15
    #adding sheet to specific postion j4 cell
    sheet_obj.add_chart(chart, "j4")
    wb_book.save(f'{webapplication_name[0][0]}.xlsx')
    print('Successfully generated the report for web application: ' + webapplication_name[0][0])

if __name__ == "__main__":
    get_csv_data()
