import requests
import sqlite3
from base64 import b64encode
import pandas as pd
import json
import re
import glob
#from datetime import datetime
from pathlib import Path
import os
from logging.handlers import TimedRotatingFileHandler
import logging
import getpass
from sys import exit
import pytz

# Base Path :: To be Edited if this Location changes
basePath = os.path.dirname(os.path.realpath('__file__'))
toBeScanPath = basePath+'\\'+'ToBeScan\\'
scanInitiatedPath = basePath+'\\'+'ScanInitiated\\'
logPath = basePath+'\\'+'_log\\'
onboardErrorPath = basePath+'\\'+'OnboardError\\'
vulScanInitiatedPath = basePath+'\\'+'vulScanInitiated\\'

# for validating an Email 
regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'

# for validating an Email 
def check(email):  
  
    # pass the regular expression 
    # and the string in search() method 
    if(re.search(regex,email)):  
        return  
          
    else:  
        print("Invalid Email address provided.") 
        exit() 

# Default Emailbox account
fromEmailID = None

# Validate default mail account
def validateMailbox(defaultMailAccount):
	import win32com.client
	global fromEmailID
	o = win32com.client.Dispatch("Outlook.Application")
	for account in o.Session.Accounts:
		if re.search(account.SmtpAddress, defaultMailAccount, re.IGNORECASE):
			fromEmailID = account
			break
	if fromEmailID:
		return
	else:
		print("Local mailbox account not found, please try with valid one")
		exit()

# Get Username
username = input("Enter Qualys Username :")
if username == "":
    print("Note : Username is mandatory to connect with Qualys. Restart the application and enter username.")
# Get Password
password = getpass.getpass("Enter Qualys Password :")
if password == "":
    print("Note : Qualys password is mandatory to connect with Qualys. Restart the application and enter username and password.")
defaultMailAccount = input("Enter your local mailbox account :")
if defaultMailAccount == "":
	print("Note : Local mailbox account is mandatory to send notification emails. Restart this application.")
check(defaultMailAccount)	
validateMailbox(defaultMailAccount)
# Email ID
emailid = input("Enter the recipient Email ID : ")
if emailid == "":
    print("Note : Recipient Email ID is mandatory to receive notification emails. Restart this application.")
check(emailid)

'''
environment = input("Enter your environment(DEV/PROD) to run: ")
if (environment == "DEV" or environment == "dev"):
    # Qualys API DEV URL
    base_url = "https://qualysapi.qg3.apps.qualys.com"
elif (environment == "PROD" or environment == "prod"):
    # Qualys API Production URL
    base_url = "https://qualysapi.qualys.com"
else:
    # Qualys API DEV URL
    base_url = "https://qualysapi.qg3.apps.qualys.com"
    environment = "DEV"
'''
base_url = "https://qualysapi.qg1.apps.qualys.in"
# Basic Auth Credentials -  Qualys Convert to Base64 encryption
userpassbyte = username+":"+password
userAndPassby = userpassbyte.encode(encoding='UTF-8')
userAndPass = b64encode(userAndPassby).decode("ascii")

headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'Basic %s' % userAndPass
}

# conn = sqlite3.connect('qualys_was_data.db')
# c = conn.cursor()

# logger config
logger = logging.getLogger('vulnerability_scanInitiation')
logger.setLevel(logging.INFO)
logname = "vulnerability_scanInitiation.log"
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler = TimedRotatingFileHandler(
    logPath+logname, when="midnight", interval=1)
handler.suffix = "%Y%m%d"
handler.setFormatter(formatter)
logger.addHandler(handler)

def GetTimeZoneName(timezone, country_code_data):

    #see if it's already a valid time zone name
    if timezone in pytz.all_timezones:
        return timezone

    #if it's a number value, then use the Etc/GMT code
    try:
        offset = int(timezone)
        if offset > 0:
            offset = '+' + str(offset)
        else:
            offset = str(offset)
        return 'Etc/GMT' + offset
    except ValueError:
        pass

    #look up the abbreviation
    country_tzones = None
    try:
        country_tzones = pytz.country_timezones[country_code_data]
    except:
        pass

    set_zones = set()
    if country_tzones is not None and len(country_tzones) > 0:
        for name in country_tzones:
            tzone = pytz.timezone(name)
            for utcoffset, dstoffset, tzabbrev in getattr(tzone, '_transition_info', [[None, None, datetime.datetime.now(tzone).tzname()]]):
                if tzabbrev.upper() == timezone.upper():
                    set_zones.add(name)

        if len(set_zones) > 0:
            return min(set_zones, key=len)

        # none matched, at least pick one in the right country
        return min(country_tzones, key=len)

    #invalid country, just try to match the timezone abbreviation to any time zone
    for name in pytz.all_timezones:
        tzone = pytz.timezone(name)
        for utcoffset, dstoffset, tzabbrev in getattr(tzone, '_transition_info', [[None, None, datetime.datetime.now(tzone).tzname()]]):
            if tzabbrev.upper() == timezone.upper():
                set_zones.add(name)
    return min(set_zones, key=len)

a=''
def timeConversion(s):
   if s[-2:] == "AM" :
      if s[:2] == '12':
          a = str('00' + s[2:8])
      else:
          a = s[:-2]
   else:
      if s[:2] == '12':
          a = s[:-2]
      else:
          a = str(int(s[:2]) + 12) + s[2:8]
   return a

# Finds type of scan
def findTypeOfScan(webAppData):
    logger.info("findTypeOfScan(webAppData) - finds type of scan")
    if(webAppData['scanType'] == "Prelaunch-Scan"):
        return "ONDEMAND"
    else:
        return "SCHEDULED"

scanList = []


def getScanListToInitiateScan():
    logger.info("getWebAppListToInitiateScan() - Getting list of json files from InitiateScan folder")
    files = glob.glob(scanInitiatedPath+"*.json")
    logger.info("getWebAppListToInitiateScan() - json file names are: "+ str(files))
    files.sort(key=os.path.getctime)
    # Add filenames in the list to initiate scan
    for file in range(len(files)):
      scanList.append(files[file])
    logger.info("getWebAppListToInitiateScan() - list of json file to initiate scan are: "+str(scanList))
    for scan in scanList:
        #logger.info("getWebAppDetails() - json file to initiate scan: "+ scan)
        file = open (scan, "r")
        # Read json file to get WebApp details
        webAppData = json.loads(file.read()) 
        webAppData['jsonFilename'] = os.path.basename(scan)
        logger.info("getWebAppDetails() - json file data: "+ str(webAppData))
        file.close()
        getDiscoveryScanID(webAppData)

def initiateScan(webAppData):
    logger.info("initiateScan(webAppData,typeOfScan) - Initiate scan for Web App by type(ondemand/scheduled)")
    # OnDemand Scan
    logger.info("initiateScan(webAppData,typeOfScan) - ONDEMAND Scan")
    api_url = "/qps/rest/3.0/launch/was/wasscan/"
    url=base_url+api_url
    logger.info("initiateScan(webAppData,typeOfScan) - Qualys url: "+ url)
    request_json="""
    {
        "ServiceRequest":{
            "data":{
                "WasScan":{
                }
            }
        }
    }
    """
    request = json.loads(request_json)
    # Build scan name 
    scanName = "Web Application Vulnerability Scan - "+webAppData['webappname']+" - " + datetime.datetime.today().strftime('%Y-%m-%d')
    request['ServiceRequest']['data']['WasScan'].update({'name':scanName})
    request['ServiceRequest']['data']['WasScan'].update({'type':'VULNERABILITY'})
    request['ServiceRequest']['data']['WasScan'].update({'mode':'ONDEMAND'})
    request['ServiceRequest']['data']['WasScan'].update({'sendMail':'false'})
    # defaultScanner is External
    if(webAppData['defaultScanner'] == 'EXTERNAL'):
        request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner']}}})
    # defaultScanner is Internal
    else:
        request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner'],'friendlyName':webAppData['friendlyName']}}})
    request['ServiceRequest']['data']['WasScan'].update({'profile':{'id':webAppData['optionProfileId']}})
    logger.info("initiateScan(webAppData,typeOfScan) - Qualys request: "+json.dumps(request))
    response = requests.post(url,headers=headers,json=request)
    logger.info("initiateScan(webAppData,typeOfScan) - Qualys response: "+response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            logger.info("initiateScan(webAppData,typeOfScan) - Initiate Scan success")
            #if folder not exist create new
            if not os.path.exists(vulScanInitiatedPath):
                logger.info("initiateScan(webAppData,typeOfScan) - Folder not exist. Creating: "+ vulScanInitiatedPath)
                os.makedirs(vulScanInitiatedPath)
            # Move file from ToBeScan to ScanInitiated folder
            filename =  webAppData['jsonFilename'] 
            logger.info("initiateScan(webAppData,typeOfScan) -  Moving file to vulScanInitiated folder: "+ filename) 
            Path(scanInitiatedPath+filename).rename(vulScanInitiatedPath+filename)
            print("Status : Vulnerability Scan for "+ webAppData['webappname'] + "Application Initiated Successfully.")
            subject = "Alert: "+webAppData['webappname']+" initiated vulnerability scan"
            text = """
Hello

    The Vulnerability scan is successfully initiated for """+ webAppData['webappname'] +"""

Thanks and Regards
Automation Team

"""
            send_email(subject,text)
        else:
            subject = "Action Required: Initiate Scan Failed: "+ webAppData['webappname']
            reason = "Server Error."
            text = """
Hello

The initiate scan is failed while performing Ondemand scan. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger.error("initiateScan(webAppData,typeOfScan) - Initiate Scan Failure.")
    elif(response == "INVALID_CREDENTIALS"):
        subject = "Action Required: Invalid Credentials"
        text = """
Hello

The Website Initiate Scan process is interrupted, due to Invalid Credentials

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.info("Invalid Credentials")
        print("Status : Invalid Credentials")
        exit()
    else:
        subject = "Action Required: Initiate Scan Failed: "+ webAppData['webappname']
        reason = "Server Error."
        text = """
Hello

The initiate scan is failed while performing Ondemand scan. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.error("initiateScan(webAppData, - Initiate Scan Failure.")

def nonAuthtoFolder(webAppData, status):
    if not os.path.exists(onboardErrorPath):
        logger.info("getDiscoveryScanID - Folder not exist. Creating: "+ scanInitiatedPath)
        os.makedirs(onboardErrorPath)
    # Move file from ToBeScan to ScanInitiated folder
    filename =  webAppData['jsonFilename']
    logger.error('get discovery scan ID Failure.')
    logger.error('getDiscoveryScanID - auth scan is ' + status)
    logger.info("getDiscoveryScanID -  Moving file to OnboardError folder: "+ filename) 
    Path(scanInitiatedPath+filename).rename(onboardErrorPath+filename)
    print("discoveryScan_Status : Scan Authentication is " + status)

def initiateScheduleScan(webAppData):
    logger.info("initiateScan(webAppData,typeOfScan) - Initiate scan for Web App by type(ondemand/scheduled)")
    timezone = webAppData['timezone'].split('-')
    timezone_name = timezone[0]
    country_code = timezone[1]
    scandate = webAppData['runningScanDate'].split(' ')
    scan_date = scandate[0]
    #Schedule Scan
    logger.info("initiateScan(webAppData,typeOfScan) - ONDEMAND Scan")
    api_url = "/qps/rest/3.0/create/was/wasscanschedule/"
    url=base_url+api_url
    logger.info("initiateScan(webAppData,typeOfScan) - Qualys url: "+ url)
    request_json="""
    {
        "ServiceRequest":{
            "data":{
                "WasScanSchedule":{
                }
            }
        }
    }
    """
    request = json.loads(request_json)
    request['ServiceRequest']['data']['WasScanSchedule'].update({'type':'VULNERABILITY'})
    #request['ServiceRequest']['data']['WasScanSchedule'].update({'mode':'ONDEMAND'})
    request['ServiceRequest']['data']['WasScanSchedule'].update({'sendMail':'false'})
    request['ServiceRequest']['data']['WasScanSchedule'].update({'progressiveScanning':'ENABLED'})
    # defaultScanner is External
    if(webAppData['defaultScanner'] == 'EXTERNAL'):
        request['ServiceRequest']['data']['WasScanSchedule'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner']}}})
    # defaultScanner is Internal
    else:
        request['ServiceRequest']['data']['WasScanSchedule'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner'],'friendlyName':webAppData['friendlyName']}}})
    request['ServiceRequest']['data']['WasScanSchedule'].update({'profile':{'id': webAppData['optionProfileId']}})
    #logger.info("initiateScheduleScan(webAppData,typeOfScan) - Qualys request: "+json.dumps(request))
    if webAppData['scanType'] == 'One Time' and webAppData['runningScanDate'] != 'null':
        # Build scan name 
        scanName = "Web Application Vulnerability Scan - "+webAppData['webappname']+" - " + datetime.datetime.today().strftime('%Y-%m-%d')
        request['ServiceRequest']['data']['WasScanSchedule'].update({'name':scanName})
        request['ServiceRequest']['data']['WasScanSchedule'].update({'scheduling':{'startDate':scan_date + 'T' + webAppData['runningScanTime'] + 'Z', 'occurrenceType':'ONCE', 'timeZone':{'code': GetTimeZoneName(timezone_name, country_code)}}})
    elif webAppData['scanType'] == 'Continuos':
        if webAppData['scanFrequency'] == 'Monthly':
            scanday = webAppData['scanDay'].split(' ')
            scanday_day = scanday[0]
            scanday_month = scanday[1]
            # Build scan name 
            scanName = "Web Application Vulnerability Scan - "+webAppData['webappname']+ "_Continous_DAST_Monthly" + " - " + datetime.datetime.today().strftime('%Y-%m-%d')
            request['ServiceRequest']['data']['WasScanSchedule'].update({'name':scanName})
            request['ServiceRequest']['data']['WasScanSchedule'].update({'scheduling':{'startDate':scan_date + 'T' + webAppData['runningScanTime'] + 'Z', 'occurrenceType': webAppData['scanFrequency'].upper(), 
            'timeZone':{'code': GetTimeZoneName(timezone_name, country_code)}, 'occurrence':{'monthlyOccurrence': {'monthlyType': 
            {'occurDayOrderInMonth': {'dayOrder': scanday_day.upper(), 'dayOfMonth': scanday_month.upper(), 'everyNMonths': 1}}}}}})
        elif webAppData['scanFrequency'] == 'Weekly':
            # Build scan name 
            scanName = "Web Application Vulnerability Scan - "+webAppData['webappname']+ "_Continous_DAST_Weekly" + " - " + datetime.datetime.today().strftime('%Y-%m-%d')
            request['ServiceRequest']['data']['WasScanSchedule'].update({'name':scanName})
            request['ServiceRequest']['data']['WasScanSchedule'].update({'scheduling':{'startDate':scan_date + 'T' + webAppData['runningScanTime'] + 'Z', 'occurrenceType': webAppData['scanFrequency'].upper(), 
            'timeZone':{'code': GetTimeZoneName(timezone_name, country_code)}, 'occurrence':{'weeklyOccurrence': {'everyNWeeks': 1, 'onDays': {'WeekDay': [webAppData['scanDay'].upper()]}}}}})
        elif webAppData['scanFrequency'] == 'Daily':
            # Build scan name 
            scanName = "Web Application Vulnerability Scan - "+webAppData['webappname']+ "_Continous_DAST_Daily" + " - " + datetime.datetime.today().strftime('%Y-%m-%d')
            request['ServiceRequest']['data']['WasScanSchedule'].update({'name':scanName})
            request['ServiceRequest']['data']['WasScanSchedule'].update({'scheduling':{'startDate':scan_date + 'T' + webAppData['runningScanTime'] + 'Z', 'occurrenceType': webAppData['scanFrequency'].upper(), 
            'timeZone':{'code': GetTimeZoneName(timezone_name, country_code)}, 'occurrence':{'dailyOccurrence': {'everyNDays': 1}}}})
    response = requests.post(url,headers=headers,json=request)
    logger.info("initiateScan(webAppData,typeOfScan) - Qualys response: "+response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            wasScanName = response_dict['ServiceResponse']['data'][0]['WasScanSchedule']['name']
            logger.info("initiateScheduleScan(webAppData,typeOfScan) - Initiate Scan success")
            #if folder not exist create new
            if not os.path.exists(vulScanInitiatedPath):
                logger.info("initiateScheduleScan(webAppData,typeOfScan) - Folder not exist. Creating: "+ vulScanInitiatedPath)
                os.makedirs(vulScanInitiatedPath)
            # Move file from ToBeScan to ScanInitiated folder
            filename =  webAppData['jsonFilename'] 
            logger.info("initiateScheduleScan(webAppData,typeOfScan) -  Moving file to vulScanInitiated folder: "+ filename) 
            Path(scanInitiatedPath+filename).rename(vulScanInitiatedPath+filename)
            print("Status : Vulnerability Scan for "+ webAppData['webappname'] + "Application Initiated Successfully.")
            subject = "Alert: "+webAppData['webappname']+" initiated vulnerability scan"
            text = """
Hello

    The Vulnerability scan is successfully initiated for """+ wasScanName +"""

Thanks and Regards
Automation Team

"""
            send_email(subject,text)

        else:
            subject = "Action Required: Initiate Scan Failed: "+ webAppData['webappname']
            reason = "Server Error."
            text = """
Hello

The initiate scan is failed while performing Schedule scan. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger.error("initiateScheduleScan(webAppData,typeOfScan) - Initiate Scan Failure.")
    elif(response == "INVALID_CREDENTIALS"):
        subject = "Action Required: Invalid Credentials"
        text = """
Hello

The Website Initiate Scan process is interrupted, due to Invalid Credentials

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.info("Invalid Credentials")
        print("Status : Invalid Credentials")
        exit()
    else:
        subject = "Action Required: Initiate Schedule Scan Failed: "+ webAppData['webappname']
        reason = "Server Error."
        text = """
Hello

The initiate Schedule scan is failed while performing Ondemand scan. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.error("initiateScheduleScan(webAppData, - Initiate Schedule Scan Failure.")

def getDiscoveryScanID(webAppData):
    id=""
    request_json="""
    {
        "ServiceRequest": {
            "filters": {
                "Criteria": [{
                    "field": "webApp.id",
                    "operator": "EQUALS"
                    }]
            }
        }
    }"""
    request = json.loads(request_json)
    request['ServiceRequest']['filters']['Criteria'][0].update({'value':webAppData['webAppId']})
    api_url="/qps/rest/3.0/search/was/wasscan"
    url=base_url+api_url
    response = requests.post(url,headers=headers,json=request)
    #print(response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            logger.info('getDiscoveryScanID - get discovery scan ID success')
            if response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'FINISHED':
                #response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'TIME_LIMIT_EXCEEDED':
                if response_dict['ServiceResponse']['data'][0]['WasScan']['summary']['authStatus'] == 'SUCCESSFUL':
                    print('status: scan authentication is successful for web application ' + webAppData['webappname'])
                    logger.info('getDiscoveryScanID(webAppData) - scan auth is successful, initiate vulnerability scan ')
                    if webAppData['scanType'] == 'One Time' and webAppData['runningScanDate'] == 'null':
                        logger.info('Initiated scheduling scan for {}'.format(webAppData['scanType']))
                        initiateScan(webAppData)
                        print('status: scan authentication is successful')
                        #print('Vulnerability scan initiated for {} {}'.format(webAppData['webappname'], webAppData['scanType']))
                    else:
                        logger.info('Initiated scheduling scan for {}'.format(webAppData['scanType']))
                        initiateScheduleScan(webAppData)
                        #print('Vulnerability scan initiated for {} {}'.format(webAppData['webappname'], webAppData['scanType']))
                elif response_dict['ServiceResponse']['data'][0]['WasScan']['summary']['authStatus'] == 'NONE':
                    logger.error('getDiscoveryScanID(webAppData) - status is NONE ')
                    nonAuthtoFolder(webAppData, 'NONE')
                elif response_dict['ServiceResponse']['data'][0]['WasScan']['summary']['authStatus'] == 'NOT_USED':
                    logger.error('getDiscoveryScanID(webAppData) -  status is NOT_USED')
                    nonAuthtoFolder(webAppData, 'NOT_USED')
                elif response_dict['ServiceResponse']['data'][0]['WasScan']['summary']['authStatus'] == 'FAILED':
                    logger.error('getDiscoveryScanID(webAppData) -  status is FAILED')
                    nonAuthtoFolder(webAppData, 'FAILED')
                elif response_dict['ServiceResponse']['data'][0]['WasScan']['summary']['authStatus'] == 'PARTIAL':
                    logger.error('getDiscoveryScanID(webAppData) - status is PARTIAL ')
                    nonAuthtoFolder(webAppData, 'PARTIAL')
            elif response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'SUBMITTED':
                logger.info('getDiscoveryScanID(webAppData)- scan status is SUBMITTED')
                print('scanStatus: still submitted for web application ' + webAppData['webappname'])
            elif response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'RUNNING':
                logger.info('getDiscoveryScanID(webAppData)- scan status is RUNNING')
                print('scanStatus: still RUNNING status for web application '+ webAppData['webappname'])
            elif response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'SCAN_NOT_LAUNCHED':
                logger.error('getDiscoveryScanID(webAppData)- scan status is SCAN_NOT_LAUNCHED')
                nonAuthtoFolder(webAppData, 'SCAN_NOT_LAUNCHED')
                print('scanStatus: scan not launched for web application ' + webAppData['webappname'])
            elif response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'SCANNER_NOT_AVAILABLE':
                logger.error('getDiscoveryScanID(webAppData)- scan status is SCANNER_NOT_AVAILABLE')
                nonAuthtoFolder(webAppData, 'SCANNER_NOT_AVAILABLE')
                print('scanStatus: scanner not available for web application ' + webAppData['webappname'])
            elif response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'ERROR':
                logger.error('getDiscoveryScanID(webAppData)- scan status is ERROR')
                nonAuthtoFolder(webAppData, 'ERROR')
                print('scanStatus: ERROR status for web application ' + webAppData['webappname'])
            elif response_dict["ServiceResponse"]['data'][0]['WasScan']['status'] == 'CANCELED':
                logger.error('getDiscoveryScanID(webAppData)- scan status is CANCELED')
                nonAuthtoFolder(webAppData, 'CANCELED')
                print('scanStatus: canceled for web application ' + webAppData['webappname'])
        else:
            subject = "Action Required: Get discoveryScan ID failed "+ webAppData['webappname']
            reason = "Server Error."
            text = """
Hello

The Get discoveryScan ID is failed. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger.error("getDiscoveryScanID(webAppData) - Get discoveryScan ID failed.")
    elif(response == "INVALID_CREDENTIALS"):
        subject = "Action Required: Invalid Credentials"
        text = """
Hello

The Get discoveryScan ID  process is interrupted, due to Invalid Credentials

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.info("Invalid Credentials")
        print("Status : Invalid Credentials")
        exit()
    else:
        subject = "Action Required: Get discoveryScan ID failed: "+ webAppData['webappname']
        reason = "Server Error."
        text = """
Hello

The Get discoveryScan ID is failed. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.error("getDiscoveryScanID(webAppData) - Get discoveryScan ID failed.")
                

                 
            # resp =  response_dict['ServiceResponse']['data'][0]['WasScan']['summary']['authStatus']
            # print(resp)
            # if (resp == 'NONE'):
            #    nonAuthscan.append(response_dict['ServiceResponse']['data'][0]['WasScan']['id'])
            # elif (resp == 'SUCCESSFUL'):
            #    authScan.append(response_dict['ServiceResponse']['data'][0]['WasScan']['id'])
            #    #initiateScan()
        
# Send Email if error
def send_email(subject,text):
    import win32com.client
    # s = win32com.client.Dispatch("Mapi.Session")
    o = win32com.client.Dispatch("Outlook.Application")
    # s.Logon("Outlook2003")
    Msg = o.CreateItem(0)
    Msg._oleobj_.Invoke(*(64209, 0, 8, 0, fromEmailID))
    Msg.To = emailid
    Msg.Subject = subject
    Msg.Body = text
    Msg.Send()
    

if __name__ == "__main__":
    ################### Process Starts #################
    #Step1: Get discovery scan details and initiate vulnerability scan
    logger.info("get discovery scan details and initiate vulnerability scan")
    getScanListToInitiateScan()
    logger.info("get discovery scan details and initiate vulnerability scan Ends")
    ################### Process End ####################
