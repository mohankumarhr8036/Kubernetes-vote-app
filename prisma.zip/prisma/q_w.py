import pandas as pd
import re
from pandas.io import excel
from datetime import datetime
import requests
from base64 import b64encode
from pathlib import Path
import os
import getpass
import json
import simplejson
from logging.handlers import TimedRotatingFileHandler
import logging
import glob
from math import isnan
import os
basePath = os.path.dirname(os.path.realpath('__file__'))


serviceNowPath = basePath+'\\'+'exceldata\\'
onboardedPath = basePath+'\\'+'Onboarded\\'
toBeScanPath = basePath+'\\'+'ToBeScan\\'
onboardErrorPath = basePath+'\\'+'OnboardError\\'
logPath = basePath+'\\'+'_log\\'
scannerPath = basePath+'\\'+'_Scanner\\'
scanInitiatedPath = basePath+'\\'+'ScanInitiated\\'

# for validating an Email 
regex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'

#scanner Appliance friendlyName
scanner = 'SISCDAST'
# for validating an Email 
def check(email):  
  
    # pass the regular expression 
    # and the string in search() method 
    if(re.search(regex,email)):  
        return  
          
    else:  
        print("Invalid Email address provided.") 
        exit() 

# Default Emailbox account
fromEmailID = None

# Validate default mail account
def validateMailbox(defaultMailAccount):
	import win32com.client
	global fromEmailID
	o = win32com.client.Dispatch("Outlook.Application")
	for account in o.Session.Accounts:
		if re.search(account.SmtpAddress, defaultMailAccount, re.IGNORECASE):
			fromEmailID = account
			break
	if fromEmailID:
		return
	else:
		print("Local mailbox account not found, please try with valid one")
		exit()

webAppList = []

# Maximum Web app to initiate scan per attempt
scanMaxApp = 10

tobeonboard = []

isError = False
newlist = []
for file in glob.glob(serviceNowPath+"*.xlsx"):
    tobeonboard.append(file)

exceldata = {}
def getDatafromExcel():
    for file in tobeonboard:
        newlist = []
        global exceldata
        df = pd.read_excel(file, engine='openpyxl', sheet_name=['AppInfo for filling by owner', 'Selenium Script'])
        #df.columns = ['Field Name', 'Response (Application team)']
        #df1 = (df[['QUALYS WAS DAST Scanning', 'Unnamed: 2']])
        # #print(df1['QUALYS WAS DAST Scanning'])
        df['AppInfo for filling by owner'] = df['AppInfo for filling by owner'].fillna('null')
        df['Selenium Script'] = df['Selenium Script'].fillna('null')
        for index, row in df['AppInfo for filling by owner'].iterrows():
           di = (row['QUALYS WAS DAST Scanning'], row['Unnamed: 4'])
           print(di)
           newlist.append(di)
        for index, row in df['Selenium Script'].iterrows():
           dj = (row['selneium'], row['script'])
           newlist.append(dj)
        dict1 = dict(newlist)
        # print(exceldata)
        exceldata['webappname'] = dict1['Application Name:']
        exceldata['url'] = dict1['Application URL:']
        exceldata['prodUrl'] = dict1['URLs and IP addresses of Production environment to be scanned:']
        exceldata['devUrl'] = dict1['URLs and IP addresses of Staging environment to be scanned:']
        exceldata['scannertype'] = dict1['Application Accessibility (Only from SEN/Public Network)']
        exceldata['loginname'] = dict1['Login Name (If autentication is associated with AD only, please provide access to: UserID: Ptuser1| Email: PTuser1.InfoSec@sony.com)\n(If not associated with AD, please create test user ID & password for access)']
        exceldata['runningScanDate'] = dict1['Preferred Start Date for running Scan ( Please mention in DD-MM-YYYY format)']
        exceldata['runningScanTime'] = dict1['Preferred Timing for running for Scans (Please mention the time range in your local time in 24 hour HH:MM format):']
        exceldata['Environment'] = dict1['Environment to be On-boarding to Scanner (PROD/Staging/Dev/Pre-PROD/QA/Etc):']
        exceldata['authPassword'] = dict1['Login Password']
        exceldata['scanType'] = dict1['Scan Type (One Time/Continuos)']
        exceldata['scanFrequency'] = dict1['Scan Frequency (In case of continous Scan) - Monthly/Quarterly/Pls Specify if Others']
        exceldata['scanDay'] = dict1['Scan Schedule details (For Continous Scan: Inform which day of Month/Week to perform Scan)']
        exceldata['sleneniumScript'] = dict1['selenium']
        exceldata['timezone'] = dict1['Timezone (eg. GMT/SGT/CST/CEST etc) Please mention as Timezone-CountryCode format']
        exceldata['authentication'] = dict1['Authenticated/Unauthenticated Scan']
        exceldata['seleniumURL'] = dict1['selenium url']
        exceldata['seleniumRegeX'] = dict1['selenium regex']
        exceldata['requestFilename'] = os.path.basename(file)
        exceldata['fileName'] = file
        print(exceldata)
        # exceldata['webappnameSelenium'] = dict1['Application Name:']
        # exceldata['webappnameBasic'] = dict1['Application Name:']
        #createStandardAuthRecord(exceldata)
        if exceldata['authentication'] == 'Authenticated':
            if exceldata['loginname'] == 'PTuser1.InfoSec@sony.com':
                getAuthenticationID(exceldata, '_Selenium')
                createWebAppSelenium(exceldata, '_Selenium')
            else:
                getAuthenticationID(exceldata, '_Basic')
                createWebAppBasic(exceldata, '_Basic')
        elif exceldata['authentication'] == 'Unauthenticated':
            createWebAppNoAuth(exceldata)
        if(not isError): 
            logger.info("createwebapp(exceldata) - Moving file to onboardedPath folder: "+ exceldata['requestFilename'])
            if not os.path.exists(onboardedPath):
                logger.info("createwebapp(exceldata) - Folder not exist. Creating:" + onboardedPath)
                os.makedirs(onboardedPath)
            Path(serviceNowPath+exceldata['requestFilename']).rename(onboardedPath+exceldata['requestFilename'])
# Get Username
username = input("Enter Qualys Username :")
if username == "":
    print("Note : Username is mandatory to connect with Qualys. Restart the application and enter username.")
# Get Password
password = getpass.getpass("Enter Qualys Password :")
if password == "":
    print("Note : Qualys password is mandatory to connect with Qualys. Restart the application and enter username and password.")
defaultMailAccount = input("Enter your local mailbox account :")
if defaultMailAccount == "":
	print("Note : Local mailbox account is mandatory to send notification emails. Restart this application.")
check(defaultMailAccount)	
validateMailbox(defaultMailAccount)
# Email ID
emailid = input("Enter the recipient Email ID : ")
if emailid == "":
    print("Note : Recipient Email ID is mandatory to receive notification emails. Restart this application.")
check(emailid)


# Basic Auth Credentials -  Qualys Convert to Base64 encryption
userpassbyte = username+":"+password
userAndPassby = userpassbyte.encode(encoding='UTF-8')
userAndPass = b64encode(userAndPassby).decode("ascii")

headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'Basic %s' % userAndPass
}

base_url = "https://qualysapi.qg1.apps.qualys.in"

# url = base_url + '/qps/xsd/3.0/was/webapp.xsd'

# response = requests.post(url, headers=headers)

# #re = json.loads(response.text)
# print(response.text)
# conn = sqlite3.connect('qualys_was_data.db')
# c = conn.cursor()
# # optionProfileId for VMO Minimal Settings
# optionProfileId = ""

# logger config
logger = logging.getLogger('website_onboarding')
logger1 = logging.getLogger('discovery_scanInitiation')
logger.setLevel(logging.INFO)
logger1.setLevel(logging.INFO)
logname = "website_onboarding.log"
logname1 = "discovery_scanInitiation.log"
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler = TimedRotatingFileHandler(
    logPath+logname, when="midnight", interval=1)
handler1 = TimedRotatingFileHandler(logPath+logname1, when="midnight", interval=1)
handler.suffix = "%Y%m%d"
handler1.suffix = "%Y%m%d"
handler.setFormatter(formatter)
handler1.setFormatter(formatter)
logger.addHandler(handler)
logger1.addHandler(handler1)


# Gets list of file names from InitiateScan folder based on scanMaxApp count
def getWebAppListToInitiateScan():
    logger.info("getWebAppListToInitiateScan() - Getting list of json files from InitiateScan folder")
    files = glob.glob(toBeScanPath+"*.json")
    logger.info("getWebAppListToInitiateScan() - json file names are: "+ str(files))
    global scanMaxApp
    if(len(files)<scanMaxApp):
        scanMaxApp = len(files)
    logger.info("getWebAppListToInitiateScan() - Initiate maximum scan per attempt "+ str(scanMaxApp))
    # sort json files by creation date
    files.sort(key=os.path.getctime)
    logger.info("getWebAppListToInitiateScan() - json file names sorted by creation time: "+ str(files))
    count = 0
    while count < scanMaxApp:
        # Add filenames in the list to initiate scan
        webAppList.append(files[count])
        count = count + 1
    logger.info("getWebAppListToInitiateScan() - list of json file to initiate scan are: "+str(webAppList))

def getWebAppDetails():
    logger.info("getWebAppDetails() - Loads Web App details from the list and initiate scan based on scan type")
    for webApp in webAppList:
        logger.info("getWebAppDetails() - json file to initiate scan: "+ webApp)
        file = open (webApp, "r") 
        # Read json file to get WebApp details
        webAppData = json.loads(file.read())
        webAppData['jsonFilename'] = os.path.basename(webApp)
        logger.info("getWebAppDetails() - json file data: "+ str(webAppData))
        file.close()
        initiateScan(webAppData)

# Returns OptionProfileId for VMO Minimal Settings
def getDefaultOptionProfileID(profileName):
    global optionProfileId
    logger.info(
        "getDefaultOptionProfileID(profileName) - Getting OptionProfileId for VMO Minimal Settings")
    request_json = """
    {
        "ServiceRequest": {
            "filters": {
                "Criteria": [{
                    "field": "name",
                    "operator": "EQUALS"
                    }]
            }
        }
    }"""
    request = json.loads(request_json)
    request['ServiceRequest']['filters']['Criteria'][0].update(
        {'value': profileName})
    api_url = "/qps/rest/3.0/search/was/optionprofile"
    url = base_url+api_url
    logger.info("getDefaultOptionProfileID(profileName) - Qualys url: "+url)
    logger.info(
        "getDefaultOptionProfileID(profileName) - Qualys request: "+json.dumps(request))
    response = requests.post(url, headers=headers, json=request)
    logger.info(
        "getDefaultOptionProfileID(profileName) - Qualys response: "+response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            optionProfileId = response_dict['ServiceResponse']['data'][0]['OptionProfile']['id']
        elif(response == "INVALID_CREDENTIALS"):
            subject = "Action Required: Invalid Credentials"
            text = """
Hello

The Website on-boarding process is interrupted, due to Invalid Credentials

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger.info("Invalid Credentials")
            print("Status : Invalid Credentials")
            exit()
        else:
            subject = "Action Required: Failed to get OptionProfileId"
            text = """
Hello

The Website on-boarding process is interrupted, due to script unable to find OptionProfileId for : """+profileName+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            exit()
    logger.info("getDefaultOptionProfileID(profileName) - OptionProfileId: "+str(id))

def myconverter(o):
    if isinstance(o, datetime):
        return o.__str__()

def createJSONFileForWebApp(exceldata):
    logger.info(
        "createJSONFileForWebApp(exceldata) - Create JSON file for successfully on-boarded Web App")
    # if folder not exist create new
    if not os.path.exists(toBeScanPath):
        logger.info(
            "createJSONFileForWebApp(exceldata) - Folder not exist. Creating: " + toBeScanPath)
        os.makedirs(toBeScanPath)
    with open(toBeScanPath+exceldata['webappname'].replace(" ", "")+'.json', 'w') as fp:
        json.dump(exceldata, fp, indent=4, default = str)
        #simplejson.dumps(exceldata, fp, default=str, ignore_nan=True)
        #simplejson.dumps(exceldata, fp, ign)
    logger.info("createJSONFileForWebApp(exceldata) - File created successfully: " +
                toBeScanPath+exceldata['webappname'].replace(" ", "")+'.json')

# def dump_data_tosql(exceldata):
#     columns = ', '.join(exceldata.keys())
#     placeholders = ', '.join('?' * len(exceldata))
#     sql = 'INSERT INTO qualys_was ({}) VALUES ({})'.format(
#         columns, placeholders)
#     values = [int(x) if isinstance(x, bool) else x for x in exceldata.values()]
#     c.execute(sql, values)
#     conn.commit()

def createSeleniumAuthRecord(exceldata, authString):
    logger.info("createWebAppAuthRecord(exceldata) - Creating Web Application Authentication Record in Qualys")
    api_url = "/qps/rest/3.0/create/was/webappauthrecord"
    request_json = """
    {
        "ServiceRequest": {
            "data": {
                "WebAppAuthRecord": {
                    "formRecord": {
                        "seleniumScript": {

                        }

                    }
                            
                        }
                    }
            }
    }
    """
    request = json.loads(request_json)
    #print(request)
    request['ServiceRequest']['data']['WebAppAuthRecord'].update({'name': exceldata['webappname'] + authString })
    request['ServiceRequest']['data']['WebAppAuthRecord']['formRecord'].update({'type': 'SELENIUM'})
    request['ServiceRequest']['data']['WebAppAuthRecord']['formRecord']['seleniumScript'].update({'name': exceldata['webappname']})
    request['ServiceRequest']['data']['WebAppAuthRecord']['formRecord']['seleniumScript'].update({'data': exceldata['sleneniumScript']})
    request['ServiceRequest']['data']['WebAppAuthRecord']['formRecord']['seleniumScript'].update({'regex': '.*'})
    #print(request)
    url = base_url+api_url
    #print(request)
    response = requests.post(url, headers=headers, json=request)
    response_dict = json.loads(response.text)
    response = response_dict['ServiceResponse']['responseCode']
    if(response == "SUCCESS"):
        exceldata['webAppAuthId' + authString] = response_dict['ServiceResponse']['data'][0]['WebAppAuthRecord']['id']
        logger.info("createWebAppAuth(exceldata) - WebApplication Auth successfully. WebAppId: " + str(exceldata['webAppAuthId'] + authString))
            #subject = "Alert: "+exceldata['webAppName']+" On-boarded successfully"
    else:
        isError = True
        #subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
        if( 'errorResolution' in response_dict['ServiceResponse']['responseErrorDetails']):
            if(response_dict['ServiceResponse']['responseErrorDetails']['errorResolution'] =="Specify another name for this web application."):
                reason = "Web App is already present in Qualys"
                print(reason)
            else:
                reason = "Server Error."
        else:
            reason = "Server Error."

def createStandardAuthRecord(exceldata, authString):
    logger.info("createWebAppStandardAuthRecord(exceldata) - Creating Web Application Standard Authentication Record in Qualys")
    api_url = "/qps/rest/3.0/create/was/webappauthrecord"
    request_json = """
    {
        "ServiceRequest": {
            "data": {
                "WebAppAuthRecord": {
                    "formRecord": {
                        "fields": {
                            "set": {
                                "WebAppAuthFormRecordField": [
                                    {},
                                    {}
                                ]
                            }
                        }
                    }         
                }
            }
        }
    }"""
    request = json.loads(request_json)
    print(request)
    request['ServiceRequest']['data']['WebAppAuthRecord'].update({'name': exceldata['webappname'] + authString})
    request['ServiceRequest']['data']['WebAppAuthRecord']['formRecord'].update({'type': 'STANDARD'})
    request['ServiceRequest']['data']['WebAppAuthRecord']['formRecord']['fields']['set']['WebAppAuthFormRecordField'][0].update({'name': 'username', 'value': exceldata['loginname']})
    request['ServiceRequest']['data']['WebAppAuthRecord']['formRecord']['fields']['set']['WebAppAuthFormRecordField'][1].update({'name': 'password', 'value': exceldata['authPassword']})
    url = base_url+api_url
    response = requests.post(url, headers=headers, json=request)
    response_dict = json.loads(response.text)
    response = response_dict['ServiceResponse']['responseCode']
    if(response == "SUCCESS"):
        exceldata['webAppAuthId' + authString] = response_dict['ServiceResponse']['data'][0]['WebAppAuthRecord']['id']
        logger.info("createWebAppAuth(exceldata) - WebApplication Auth successfully. WebAppId: " + str(exceldata['webAppAuthId' + authString] ))
            #subject = "Alert: "+exceldata['webAppName']+" On-boarded successfully"
    else:
        isError = True
        #subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
        if( 'errorResolution' in response_dict['ServiceResponse']['responseErrorDetails']):
            if(response_dict['ServiceResponse']['responseErrorDetails']['errorResolution'] =="Specify another name for this web application."):
                reason = "Web App is already present in Qualys"
                print(reason)
            else:
                reason = "Server Error."
        else:
            reason = "Server Error."

def getAuthenticationID(exceldata, authString):
    id=""
    request_json="""
    {
        "ServiceRequest": {
            "filters": {
                "Criteria": [{
                    "field": "name",
                    "operator": "EQUALS"
                    }]
            }
        }
    }"""
    request = json.loads(request_json)
    request['ServiceRequest']['filters']['Criteria'][0].update({'value':exceldata['webappname'] + authString})
    api_url="/qps/rest/3.0/search/was/webappauthrecord"
    url=base_url+api_url
    response = requests.post(url,headers=headers,json=request)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            if 'data' in response_dict['ServiceResponse']:
               exceldata['webAppAuthId' + authString] = response_dict['ServiceResponse']['data'][0]['WebAppAuthRecord']['id']
            else:
                if exceldata['authentication'] == 'Authenticated':
                    if exceldata['loginname'] == 'PTuser1.InfoSec@sony.com':
                        createSeleniumAuthRecord(exceldata, authString)
                    else:
                        createStandardAuthRecord(exceldata, authString)
        else:
            isError = True
            #subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
            if( 'errorResolution' in response_dict['ServiceResponse']['responseErrorDetails']):
                if(response_dict['ServiceResponse']['responseErrorDetails']['errorResolution'] =="Specify another name for this web application."):
                    reason = "Authentication is already present in Qualys"
                else:
                    reason = "Server Error."
            else:
                reason = "Server Error."
    elif(response == "INVALID_CREDENTIALS"):
        logger.info("Action Required: Invalid Credentials")
    else:
        logger.info("getAuthenticationID is failed")


def createWebAppSelenium(exceldata, authString):
    global isError
    logger.info("createWebApp(exceldata) - Creating Web Application in Qualys")
    api_url = "/qps/rest/3.0/create/was/webapp/"
    request_json = """
    {
        "ServiceRequest": {
            "data": {
                "WebApp":{
                    "crawlingScripts": {
                        "set": {
                            "SeleniumScript": {

                            }
                        }

                    }
                }
            }
        }
    }
    """
    #tagId = getPrelaunchTagID("WAS_Pre_launch_Scan_Req")
    request = json.loads(request_json)
    #print(request)
    request['ServiceRequest']['data']['WebApp'].update({'name': exceldata['webappname']})
    if exceldata['Environment'] == 'PROD':
        request['ServiceRequest']['data']['WebApp'].update({'url': exceldata['prodUrl']})
    elif exceldata['Environment'] == 'Dev':
        request['ServiceRequest']['data']['WebApp'].update({'url': exceldata['devUrl']})
    request['ServiceRequest']['data']['WebApp']['crawlingScripts']['set']['SeleniumScript'].update({'name': 'test'})
    request['ServiceRequest']['data']['WebApp']['crawlingScripts']['set']['SeleniumScript'].update({'startingUrl': exceldata['seleniumURL']})
    request['ServiceRequest']['data']['WebApp']['crawlingScripts']['set']['SeleniumScript'].update({'data': exceldata['sleneniumScript']})
    request['ServiceRequest']['data']['WebApp']['crawlingScripts']['set']['SeleniumScript'].update({'requiresAuthentication': True})
    request['ServiceRequest']['data']['WebApp']['crawlingScripts']['set']['SeleniumScript'].update({'startingUrlRegex': True})
    request['ServiceRequest']['data']['WebApp']['crawlingScripts']['set']['SeleniumScript'].update({'regex': exceldata['seleniumRegeX']})
    #createAuthRecord(exceldata)
    request['ServiceRequest']['data']['WebApp'].update({'authRecords': {'set': {'WebAppAuthRecord': {'id': exceldata['webAppAuthId' + authString]}}}})
    if(exceldata['scannertype'] == "Public Network"):
        logger.info("createWebApp(exceldata) - EXTERNAL Scanner")
        request['ServiceRequest']['data']['WebApp'].update({'defaultScanner': {'type': 'EXTERNAL'}})
        exceldata['defaultScanner'] = "EXTERNAL"
    else:
        logger.info("createWebApp(exceldata) - INTERNAL Scanner")
        request['ServiceRequest']['data']['WebApp'].update({'defaultScanner': {'type': 'INTERNAL', 'friendlyName': scanner }})
        exceldata['defaultScanner'] = "INTERNAL"
        exceldata['friendlyName'] = scanner
    request['ServiceRequest']['data']['WebApp'].update({'defaultProfile': {'id': optionProfileId}})
    exceldata['optionProfileId'] = optionProfileId
    request['ServiceRequest']['data']['WebApp'].update({'comments': {'set': {'Comment': {'contents': 'Created by Automation'}}}})
    api_url = "/qps/rest/3.0/create/was/webapp/"
    url = base_url+api_url
    #print(request)
    response = requests.post(url, headers=headers, json=request)
    logger.info("createWebApp(exceldata) - Qualys response: " + response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            exceldata['webAppId'] = response_dict['ServiceResponse']['data'][0]['WebApp']['id']
            exceldata['status'] = 'onboarded'
            logger.info("createWebApp(exceldata) - WebApplication Onboarded successfully. WebAppId: " + str(exceldata['webAppId']))
            #dump_data_tosql(exceldata)
            createJSONFileForWebApp(exceldata)
            #subject = "Alert: "+exceldataData['webAppName']+" On-boarded successfully"
            subject = "Alert: "+exceldata['webappname']+" On-boarded successfully"
            text = """
Hello

    The Website is On-boarded successfully for """+ exceldata['webappname'] +"""

Thanks and Regards
Automation Team

"""
            send_email(subject,text)
            # if folder not exist create new
            if not os.path.exists(onboardedPath):
                logger.info("createWebApp(excelData) - Folder not exist. Creating: "+ onboardedPath)
                os.makedirs(onboardedPath)
                
        else:
            isError = True
            subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
            if( 'errorResolution' in response_dict['ServiceResponse']['responseErrorDetails']):
                if(response_dict['ServiceResponse']['responseErrorDetails']['errorResolution'] =="Specify another name for this web application."):
                    reason = "Web App is already present in Qualys"
                else:
                    reason = "Server Error."
            else:
                reason = "Server Error."
                #print("Authentication failed!.")
            text = """
Hello

The Website on-boarding process is interrupted, Please find the details.

File Name: """+exceldata['fileName']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger.error("createWebApp(excelData) - WebApplication Onboard Failure.")
            logger.info("createWebApp(excelData) - Moving file to OnboardError folder: "+ exceldata['requestFilename'])  
            if not os.path.exists(onboardErrorPath):
                logger.info("createWebApp(excelData) - Folder not exist. Creating:" + onboardErrorPath)
                os.makedirs(onboardErrorPath)  
            Path(serviceNowPath+exceldata['requestFilename']).rename(onboardErrorPath+exceldata['requestFilename'])
    else:
        isError = True
        subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
        reason = "Server Error."
        text = """
Hello

The Website on-boarding process is interrupted, Please find the details.

File Name: """+exceldata['fileName']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.error("createWebApp(excelData) - WebApplication Onboard Failure.")
        logger.info("createWebApp(excelData) - Moving file to OnboardError folder: "+ exceldata['requestFilename'])  
        if not os.path.exists(onboardErrorPath):
            logger.info("createWebApp(excelData) - Folder not exist. Creating:" + onboardErrorPath)
            os.makedirs(onboardErrorPath)  
        Path(serviceNowPath+exceldata['requestFilename']).rename(onboardErrorPath+exceldata['requestFilename'])

def createWebAppBasic(exceldata, authString):
    global isError
    print(exceldata)
    logger.info("createWebApp(exceldata) - Creating Web Application in Qualys")
    api_url = "/qps/rest/3.0/create/was/webapp/"
    request_json = """
    {
        "ServiceRequest": {
            "data": {
                "WebApp":{
                    
            }
        }
    }
    }    
    """
    #tagId = getPrelaunchTagID("WAS_Pre_launch_Scan_Req")
    request = json.loads(request_json)
    #print(request)
    request['ServiceRequest']['data']['WebApp'].update({'name': exceldata['webappname']})
    if exceldata['Environment'] == 'PROD':
        request['ServiceRequest']['data']['WebApp'].update({'url': exceldata['prodUrl']})
    elif exceldata['Environment'] == 'Dev':
        request['ServiceRequest']['data']['WebApp'].update({'url': exceldata['devUrl']})
    #createAuthRecord(exceldata)
    request['ServiceRequest']['data']['WebApp'].update({'authRecords': {'set': {'WebAppAuthRecord': {'id': exceldata['webAppAuthId' + authString]}}}})
    if(exceldata['scannertype'] == "Public Network"):
        logger.info("createWebApp(exceldata) - EXTERNAL Scanner")
        request['ServiceRequest']['data']['WebApp'].update({'defaultScanner': {'type': 'EXTERNAL'}})
        exceldata['defaultScanner'] = "EXTERNAL"
    else:
        logger.info("createWebApp(exceldata) - INTERNAL Scanner")
        request['ServiceRequest']['data']['WebApp'].update({'defaultScanner': {'type': 'INTERNAL', 'friendlyName': scanner }})
        exceldata['defaultScanner'] = "INTERNAL"
        exceldata['friendlyName'] = scanner
    request['ServiceRequest']['data']['WebApp'].update({'defaultProfile': {'id': optionProfileId}})
    exceldata['optionProfileId'] = optionProfileId
    request['ServiceRequest']['data']['WebApp'].update({'comments': {'set': {'Comment': {'contents': 'Created by Automation'}}}})
    api_url = "/qps/rest/3.0/create/was/webapp/"
    url = base_url+api_url
    #print(request)
    response = requests.post(url, headers=headers, json=request)
    logger.info("createWebApp(exceldata) - Qualys response: " + response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            exceldata['webAppId'] = response_dict['ServiceResponse']['data'][0]['WebApp']['id']
            exceldata['status'] = 'onboarded'
            logger.info("createWebApp(exceldata) - WebApplication Onboarded successfully. WebAppId: " + str(exceldata['webAppId']))
            #dump_data_tosql(exceldata)
            createJSONFileForWebApp(exceldata)
            #subject = "Alert: "+exceldataData['webAppName']+" On-boarded successfully"
            subject = "Alert: "+exceldata['webappname']+" On-boarded successfully"
            text = """
Hello

    The Website is On-boarded successfully for """+ exceldata['webappname'] +"""

Thanks and Regards
Automation Team

"""
            send_email(subject,text)
            # if folder not exist create new
            if not os.path.exists(onboardedPath):
                logger.info("createWebApp(excelData) - Folder not exist. Creating: "+ onboardedPath)
                os.makedirs(onboardedPath)
                
        else:
            isError = True
            subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
            if( 'errorResolution' in response_dict['ServiceResponse']['responseErrorDetails']):
                if(response_dict['ServiceResponse']['responseErrorDetails']['errorResolution'] =="Specify another name for this web application."):
                    reason = "Web App is already present in Qualys"
                else:
                    reason = "Server Error."
            else:
                reason = "Server Error."
                #print("Authentication failed!.")
            text = """
Hello

The Website on-boarding process is interrupted, Please find the details.

File Name: """+exceldata['fileName']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger.error("createWebApp(excelData) - WebApplication Onboard Failure.")
            logger.info("createWebApp(excelData) - Moving file to OnboardError folder: "+ exceldata['requestFilename'])  
            if not os.path.exists(onboardErrorPath):
                logger.info("createWebApp(excelData) - Folder not exist. Creating:" + onboardErrorPath)
                os.makedirs(onboardErrorPath)  
            Path(serviceNowPath+exceldata['requestFilename']).rename(onboardErrorPath+exceldata['requestFilename'])
    else:
        isError = True
        subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
        reason = "Server Error."
        text = """
Hello

The Website on-boarding process is interrupted, Please find the details.

File Name: """+exceldata['fileName']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.error("createWebApp(excelData) - WebApplication Onboard Failure.")
        logger.info("createWebApp(excelData) - Moving file to OnboardError folder: "+ exceldata['requestFilename'])  
        if not os.path.exists(onboardErrorPath):
            logger.info("createWebApp(excelData) - Folder not exist. Creating:" + onboardErrorPath)
            os.makedirs(onboardErrorPath)  
        Path(serviceNowPath+exceldata['requestFilename']).rename(onboardErrorPath+exceldata['requestFilename'])

def createWebAppNoAuth(exceldata):
    global isError
    logger.info("createWebApp(exceldata) - Creating Web Application in Qualys")
    api_url = "/qps/rest/3.0/create/was/webapp/"
    request_json = """
    {
        "ServiceRequest": {
            "data": {
                "WebApp":{
                    
            }
        }
    }
    }    
    """
    #tagId = getPrelaunchTagID("WAS_Pre_launch_Scan_Req")
    request = json.loads(request_json)
    #print(request)
    request['ServiceRequest']['data']['WebApp'].update({'name': exceldata['webappname']})
    if exceldata['Environment'] == 'PROD':
        request['ServiceRequest']['data']['WebApp'].update({'url': exceldata['prodUrl']})
    elif exceldata['Environment'] == 'Dev':
        request['ServiceRequest']['data']['WebApp'].update({'url': exceldata['devUrl']})
    #request['ServiceRequest']['data']['WebApp'].update({'authRecords': {'set': {'WebAppAuthRecord': {'id': exceldata['webAppAuthId' + authString]}}}})
    if(exceldata['scannertype'] == "Public Network"):
        logger.info("createWebApp(exceldata) - EXTERNAL Scanner")
        request['ServiceRequest']['data']['WebApp'].update({'defaultScanner': {'type': 'EXTERNAL'}})
        exceldata['defaultScanner'] = "EXTERNAL"
    else:
        logger.info("createWebApp(exceldata) - INTERNAL Scanner")
        request['ServiceRequest']['data']['WebApp'].update({'defaultScanner': {'type': 'INTERNAL', 'friendlyName': scanner }})
        exceldata['defaultScanner'] = "INTERNAL"
        exceldata['friendlyName'] = scanner
    request['ServiceRequest']['data']['WebApp'].update({'defaultProfile': {'id': optionProfileId}})
    exceldata['optionProfileId'] = optionProfileId
    request['ServiceRequest']['data']['WebApp'].update({'comments': {'set': {'Comment': {'contents': 'Created by Automation'}}}})
    api_url = "/qps/rest/3.0/create/was/webapp/"
    url = base_url+api_url
    #print(request)
    response = requests.post(url, headers=headers, json=request)
    logger.info("createWebApp(exceldata) - Qualys response: " + response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            exceldata['webAppId'] = response_dict['ServiceResponse']['data'][0]['WebApp']['id']
            exceldata['status'] = 'onboarded'
            logger.info("createWebApp(exceldata) - WebApplication Onboarded successfully. WebAppId: " + str(exceldata['webAppId']))
            #dump_data_tosql(exceldata)
            createJSONFileForWebApp(exceldata)
            #subject = "Alert: "+exceldataData['webAppName']+" On-boarded successfully"
            subject = "Alert: "+exceldata['webappname']+" On-boarded successfully"
            text = """
Hello

    The Website is On-boarded successfully for """+ exceldata['webappname'] +"""

Thanks and Regards
Automation Team

"""
            send_email(subject,text)
            # if folder not exist create new
            if not os.path.exists(onboardedPath):
                logger.info("createWebApp(excelData) - Folder not exist. Creating: "+ onboardedPath)
                os.makedirs(onboardedPath)
                
        else:
            isError = True
            subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
            if( 'errorResolution' in response_dict['ServiceResponse']['responseErrorDetails']):
                if(response_dict['ServiceResponse']['responseErrorDetails']['errorResolution'] =="Specify another name for this web application."):
                    reason = "Web App is already present in Qualys"
                else:
                    reason = "Server Error."
            else:
                reason = "Server Error."
                #print("Authentication failed!.")
            text = """
Hello

The Website on-boarding process is interrupted, Please find the details.

File Name: """+exceldata['fileName']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger.error("createWebApp(excelData) - WebApplication Onboard Failure.")
            logger.info("createWebApp(excelData) - Moving file to OnboardError folder: "+ exceldata['requestFilename'])  
            if not os.path.exists(onboardErrorPath):
                logger.info("createWebApp(excelData) - Folder not exist. Creating:" + onboardErrorPath)
                os.makedirs(onboardErrorPath)  
            Path(serviceNowPath+exceldata['requestFilename']).rename(onboardErrorPath+exceldata['requestFilename'])
    else:
        isError = True
        subject = "Action Required: "+exceldata['webappname']+" Onboarding - Failed"
        reason = "Server Error."
        text = """
Hello

The Website on-boarding process is interrupted, Please find the details.

File Name: """+exceldata['fileName']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger.error("createWebApp(excelData) - WebApplication Onboard Failure.")
        logger.info("createWebApp(excelData) - Moving file to OnboardError folder: "+ exceldata['requestFilename'])  
        if not os.path.exists(onboardErrorPath):
            logger.info("createWebApp(excelData) - Folder not exist. Creating:" + onboardErrorPath)
            os.makedirs(onboardErrorPath)  
        Path(serviceNowPath+exceldata['requestFilename']).rename(onboardErrorPath+exceldata['requestFilename'])

# Initiate Discovery scan for Web App by type(ondemand)
def initiateScan(webAppData):
    logger1.info("initiateScan(webAppData) - Initiate Discovery scan for Web App by type(ondemand/scheduled)")
    # OnDemand Scan
    logger1.info("initiateScan(webAppData) - ONDEMAND Scan")
    api_url = "/qps/rest/3.0/launch/was/wasscan/"
    url=base_url+api_url
    logger1.info("initiateScan(webAppData) - Qualys url: "+ url)
    request_json="""
    {
        "ServiceRequest":{
            "data":{
                "WasScan":{
                }
            }
        }
    }
    """
    request = json.loads(request_json)
    # Build scan name 
    scanName = "Web Application Discovery Scan - "+webAppData['webappname']+" - " + datetime.today().strftime('%Y-%m-%d')
    request['ServiceRequest']['data']['WasScan'].update({'name':scanName})
    request['ServiceRequest']['data']['WasScan'].update({'type':'DISCOVERY'})
    request['ServiceRequest']['data']['WasScan'].update({'mode':'ONDEMAND'})
    request['ServiceRequest']['data']['WasScan'].update({'sendMail':'false'})
    if webAppData['authentication'] == 'Authenticated':
        if webAppData['loginname'] == 'PTuser1.InfoSec@sony.com':
            # defaultScanner is External
            if(webAppData['defaultScanner'] == 'EXTERNAL'):
                request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner']}, 'webAppAuthRecord':{'id': webAppData['webAppAuthId_Selenium']}}})
            # defaultScanner is Internal
            else:
                request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner'],'friendlyName':webAppData['friendlyName']}, 'webAppAuthRecord':{'id': webAppData['webAppAuthId_Selenium']}}})
        else:
            # defaultScanner is External
            if(webAppData['defaultScanner'] == 'EXTERNAL'):
                request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner']}, 'webAppAuthRecord':{'id': webAppData['webAppAuthId_Basic']}}})
            # defaultScanner is Internal
            else:
                request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner'],'friendlyName':webAppData['friendlyName']}, 'webAppAuthRecord':{'id': webAppData['webAppAuthId_Basic']}}})
    elif webAppData['authentication'] == 'Unauthenticated':
        # defaultScanner is External
        if(webAppData['defaultScanner'] == 'EXTERNAL'):
            request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner']}}})
        # defaultScanner is Internal
        else:
            request['ServiceRequest']['data']['WasScan'].update({'target':{'webApp':{'id':webAppData['webAppId']},'scannerAppliance':{'type':webAppData['defaultScanner'],'friendlyName':webAppData['friendlyName']}}})
    request['ServiceRequest']['data']['WasScan'].update({'profile':{'id':webAppData['optionProfileId']}})
    logger1.info("initiateScan(webAppData) - Qualys request: "+json.dumps(request))
    response = requests.post(url,headers=headers,json=request)
    logger1.info("initiateScan(webAppData) - Qualys response: "+response.text)
    if(response.status_code == 200 or response.status_code == 201):
        response_dict = json.loads(response.text)
        response = response_dict['ServiceResponse']['responseCode']
        if(response == "SUCCESS"):
            logger1.info("initiateScan(webAppData) - Initiate Scan success")
            # if folder not exist create new
            if not os.path.exists(scanInitiatedPath):
                logger1.info("initiateScan(webAppData) - Folder not exist. Creating: "+ scanInitiatedPath)
                os.makedirs(scanInitiatedPath)
            # Move file from ToBeScan to ScanInitiated folder
            filename =  webAppData['jsonFilename'] 
            logger1.info("initiateScan(webAppData) -  Moving file to ScanInitiated folder: "+ filename) 
            Path(toBeScanPath+filename).rename(scanInitiatedPath+filename)
            print("Status : Discovery Scan for " + webAppData['webappname'] + "Application Initiated Successfully.")
        else:
            subject = "Action Required: Initiate Scan Failed: "+ webAppData['webappname']
            reason = "Server Error."
            text = """
Hello

The initiate scan is failed while performing Ondemand scan. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
            send_email(subject,text)
            logger1.error("initiateScan(webAppData) - Initiate Scan Failure.")
    elif(response == "INVALID_CREDENTIALS"):
        subject = "Action Required: Invalid Credentials"
        text = """
Hello

The Website Initiate Scan process is interrupted, due to Invalid Credentials

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger1.info("Invalid Credentials")
        print("Status : Invalid Credentials")
        exit()
    else:
        subject = "Action Required: Initiate Scan Failed: "+ webAppData['webappname']
        reason = "Server Error."
        text = """
Hello

The initiate scan is failed while performing Ondemand scan. Please find the details

WebApp Name: """+webAppData['webappname']+"""
Reason: """+reason+"""

Thanks and Regards
Automation Team
"""
        send_email(subject,text)
        logger1.error("initiateScan(webAppData, - Initiate Scan Failure.")

# Send Email if error
def send_email(subject,text):
    import win32com.client
    # s = win32com.client.Dispatch("Mapi.Session")
    o = win32com.client.Dispatch("Outlook.Application")
    # s.Logon("Outlook2003")
    Msg = o.CreateItem(0)
    Msg._oleobj_.Invoke(*(64209, 0, 8, 0, fromEmailID))
    Msg.To = emailid
    Msg.Subject = subject
    Msg.Body = text
    Msg.Send()

if __name__ == "__main__":
    ################### Process Starts #################
    logger.info("Onboarding Website process Started")
    # Get OptionProfileId for VMO Minimal Settings
    getDefaultOptionProfileID('SISC_option_profile')
    # Read data from excel file(excel data)
    getDatafromExcel()
    logger.info("Onboarding Website process Ends")
    ################### Process End ####################

    ################### Process Starts #################
    #Step1: Get Web App list to initiate scan
    logger.info("Initiate Scan process Started")
    getWebAppListToInitiateScan()
    #Step2: Load Web App details from JSON file and initiate scan
    getWebAppDetails()
    logger.info("Initiate Scan process Ends")
    ################### Process End ####################
